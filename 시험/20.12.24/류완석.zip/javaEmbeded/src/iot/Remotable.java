package iot;

public interface Remotable {
	public boolean turnOn();
	public boolean turnOff();
}
