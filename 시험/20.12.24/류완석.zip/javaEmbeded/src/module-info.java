module javaEmbeded {
}