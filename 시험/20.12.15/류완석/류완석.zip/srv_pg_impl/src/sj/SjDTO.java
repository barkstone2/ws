package sj;

public class SjDTO {
	private String name;
	private String sname;
	private int mun_1;
	private int mun_2;
	private int mun_3;
	private int mun_4;
	private int mun_5;
	private String mun_ox_1;
	private String mun_ox_2;
	private String mun_ox_3;
	private String mun_ox_4;
	private String mun_ox_5;
	private int jumsu;
	
	public SjDTO() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getMun_1() {
		return mun_1;
	}

	public void setMun_1(int mun_1) {
		this.mun_1 = mun_1;
	}

	public int getMun_2() {
		return mun_2;
	}

	public void setMun_2(int mun_2) {
		this.mun_2 = mun_2;
	}

	public int getMun_3() {
		return mun_3;
	}

	public void setMun_3(int mun_3) {
		this.mun_3 = mun_3;
	}

	public int getMun_4() {
		return mun_4;
	}

	public void setMun_4(int mun_4) {
		this.mun_4 = mun_4;
	}

	public int getMun_5() {
		return mun_5;
	}

	public void setMun_5(int mun_5) {
		this.mun_5 = mun_5;
	}

	public String getMun_ox_1() {
		return mun_ox_1;
	}

	public void setMun_ox_1(String mun_ox_1) {
		this.mun_ox_1 = mun_ox_1;
	}

	public String getMun_ox_2() {
		return mun_ox_2;
	}

	public void setMun_ox_2(String mun_ox_2) {
		this.mun_ox_2 = mun_ox_2;
	}

	public String getMun_ox_3() {
		return mun_ox_3;
	}

	public void setMun_ox_3(String mun_ox_3) {
		this.mun_ox_3 = mun_ox_3;
	}

	public String getMun_ox_4() {
		return mun_ox_4;
	}

	public void setMun_ox_4(String mun_ox_4) {
		this.mun_ox_4 = mun_ox_4;
	}

	public String getMun_ox_5() {
		return mun_ox_5;
	}

	public void setMun_ox_5(String mun_ox_5) {
		this.mun_ox_5 = mun_ox_5;
	}

	public int getJumsu() {
		return jumsu;
	}

	public void setJumsu(int jumsu) {
		this.jumsu = jumsu;
	}
	
	
}
