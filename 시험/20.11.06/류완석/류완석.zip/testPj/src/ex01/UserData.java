package ex01;

public class UserData {
	private String dbId = "hong";
	private String dbPwd = "h1234";
	
	public UserData() {
	}

	public String getDbId() {
		return dbId;
	}

	public void setDbId(String dbId) {
		this.dbId = dbId;
	}

	public String getDbPwd() {
		return dbPwd;
	}

	public void setDbPwd(String dbPwd) {
		this.dbPwd = dbPwd;
	}
	
	
}
