
create user sihum
identified by 1234;

grant connect, resource, dba to sihum;

select * from tab;